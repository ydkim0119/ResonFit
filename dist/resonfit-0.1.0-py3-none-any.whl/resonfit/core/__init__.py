"""
Core functionality for the ResonFit package.

This module provides the base classes and infrastructure for the resonator fitting process.
"""
